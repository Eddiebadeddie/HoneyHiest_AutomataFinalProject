HONEY HEIST READ ME

To play:
Download Honey Hiest_Data.zip

Open zip file

Exctract the files (optional)

Click Honey Heist.exe

Enjoy

You can quit the game whenever by hitting the ESC key